=== SamaHesab Support Center ===
Contributors: samarayanehkish
Tags: support, helpdesk, tickets, bug-report, erp
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

مرکزِ پشتیبانی و بازخوردِ سما حساب برای وردپرس — دریافتِ گزارشِ باگ/درخواستِ قابلیت/تیکت از نصب‌های ERP،
دانشنامه، یادداشت‌های نسخه و پرتالِ مشتری.

== Description ==

این پلاگین، سمتِ سرورِ «مرکزِ پشتیبانیِ» نرم‌افزارِ حسابداریِ سما حساب است و روی سایتِ وردپرسِ
شرکت (kishwifi.com) نصب می‌شود. کلاینتِ ERP از طریقِ REST با این پلاگین گفت‌وگو می‌کند.

* Custom Post Typeها: تیکت، گزارشِ باگ، درخواستِ قابلیت، یادداشتِ نسخه، مقالهٔ دانشنامه.
* REST API امن با «کلید-API» در فضای‌نامِ `samahesab/v1`.
* منوی ادمینِ «SamaHesab» با داشبوردِ آمار + مدیریتِ مشتری/کلید-API.
* پرتالِ مشتری با شورت‌کد.
* اعلانِ ایمیلیِ ثبت/تغییرِ وضعیت.
* امنیت: فقط دادهٔ پشتیبانی/تشخیصی — هیچ دادهٔ مالی.

== مسیرهای REST ==

پایه: `https://SITE/wp-json/samahesab/v1`
احراز: هدرِ `X-SamaHesab-ApiKey` (+ اختیاری `X-SamaHesab-Customer`, `X-SamaHesab-License`).

* `POST /bug`              — ثبتِ گزارشِ باگ → `{ "Id": "<شناسه>" }`
* `POST /feature`          — ثبتِ درخواستِ قابلیت → `{ "Id": "..." }`
* `POST /ticket`           — ثبتِ تیکت → `{ "Id": "..." }`
* `GET  /releases`         — فهرستِ یادداشت‌های نسخه
* `GET  /articles?search=` — جست‌وجوی دانشنامه
* `GET  /status/<id>`      — وضعیتِ یک رکورد

== شورت‌کدها ==

* `[samahesab_portal]`   — تیکت‌ها/درخواست‌های مشتریِ واردشده.
* `[samahesab_kb]`       — دانشنامه با جست‌وجو.
* `[samahesab_releases]` — یادداشت‌های نسخه.

== نصب ==

1. پوشهٔ `samahesab-support-center` را در `wp-content/plugins/` بگذارید.
2. از «افزونه‌ها» فعال کنید (CPTها و مسیرها ساخته می‌شوند).
3. به «SamaHesab → مشتریان (کلید-API)» بروید و برای هر نصبِ ERP یک کلید بسازید.
4. کلید/شناسهٔ مشتری/آدرسِ سایت را در «تنظیماتِ پشتیبانیِ» سما حساب وارد کنید.

== Changelog ==

= 1.0.0 =
* نسخهٔ نخست: CPTها، REST، احرازِ کلید-API، داشبوردِ ادمین، پرتالِ مشتری، اعلانِ ایمیلی.
